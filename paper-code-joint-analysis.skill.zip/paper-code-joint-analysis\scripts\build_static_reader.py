#!/usr/bin/env python3
"""Build the reusable static reader for paper-code-joint-analysis outputs."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path


REQUIRED_FILES = [
    "analysis_bundle.json",
    "paper_reading_report.md",
    "paper_questions_for_code.md",
    "paper_code_crosswalk.md",
    "experiment_joint_reading.md",
    "implementation_omissions.md",
    "diagrams.md",
    "modify_method_guide.md",
    "validation_report.md",
]


def copytree_contents(src: Path, dst: Path) -> None:
    dst.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        target = dst / item.name
        if item.is_dir():
            if target.exists():
                shutil.rmtree(target)
            shutil.copytree(item, target)
        else:
            shutil.copy2(item, target)


def find_vendor(analysis_dir: Path, explicit: str | None) -> Path | None:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit))
    candidates.extend([
        analysis_dir / "site" / "vendor",
        analysis_dir.parent / "site" / "vendor",
        analysis_dir.parent.parent / "site" / "vendor",
        Path.cwd() / "site" / "vendor",
    ])
    for candidate in candidates:
        if (candidate / "mermaid.min.js").exists() or (candidate / "katex" / "katex.min.js").exists():
            return candidate
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="Build static reader from analysis_bundle.json and Markdown artifacts.")
    parser.add_argument("analysis_dir", help="Directory containing analysis_bundle.json and companion Markdown files.")
    parser.add_argument("--out", default=None, help="Output site directory. Defaults to <analysis_dir>/site.")
    parser.add_argument("--vendor-source", default=None, help="Optional directory containing mermaid.min.js and/or katex/.")
    parser.add_argument("--force", action="store_true", help="Overwrite an existing site directory.")
    args = parser.parse_args()

    analysis_dir = Path(args.analysis_dir).resolve()
    if not analysis_dir.exists():
        raise SystemExit(f"analysis_dir does not exist: {analysis_dir}")
    missing = [name for name in REQUIRED_FILES if not (analysis_dir / name).exists()]
    if missing:
        raise SystemExit("missing required analysis files: " + ", ".join(missing))

    skill_dir = Path(__file__).resolve().parents[1]
    template = skill_dir / "assets" / "reader-template"
    out_dir = Path(args.out).resolve() if args.out else analysis_dir / "site"
    if out_dir.exists() and args.force:
        shutil.rmtree(out_dir)
    elif out_dir.exists() and any(out_dir.iterdir()):
        raise SystemExit(f"output directory exists and is not empty: {out_dir}; use --force")
    copytree_contents(template, out_dir)

    vendor = find_vendor(analysis_dir, args.vendor_source)
    if vendor:
        vendor_out = out_dir / "vendor"
        vendor_out.mkdir(parents=True, exist_ok=True)
        if vendor.resolve() != vendor_out.resolve():
            if (vendor / "mermaid.min.js").exists():
                shutil.copy2(vendor / "mermaid.min.js", vendor_out / "mermaid.min.js")
            if (vendor / "katex").exists():
                target = vendor_out / "katex"
                if target.exists():
                    shutil.rmtree(target)
                shutil.copytree(vendor / "katex", target)

    print(f"reader: {out_dir / 'index.html'}")
    if vendor:
        print(f"vendor: {vendor}")
    else:
        print("vendor: not found; reader will use formula/diagram fallbacks")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
